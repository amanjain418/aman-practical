<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;


class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $product = DB::table('products')->select()->paginate(1);

        return view('listing',['product'=>$product]);
    }


    public function create()
    {
        return view('add');
    }


    public function addproduct(Request $request)
    {
        $car = $request->car;
        $cell = $request->cell;
        $cell_model = $request->cell_model;
        $cell_price = $request->cell_price;
        $car_model = $request->car_model;
        $car_price = $request->car_price;


        DB::table('products')->insert(['cell_phone'=>$cell,'car'=>$car,'cell_model'=>$cell_model,'cell_price'=>$cell_price,'car_model'=>$car_model,'car_price'=>$car_price]);
        return redirect()->route('product.listing');

    }


    public function delete($id)
    {
        DB::table('products')->where('id','=',$id)->delete();
        return redirect()->route('product.listing');
    }

    public function edit($id)
    {
        $products =  DB::table('products')->where('id','=',$id)->select()->first();
        return view('edit',['product'=>$products]);
    }

    public function update(Request $request)
    {
        $id = $request->id;
        $car = $request->car;
        $cell = $request->cell;
        $cell_model = $request->cell_model;
        $cell_price = $request->cell_price;
        $car_model = $request->car_model;
        $car_price = $request->car_price;
        $data = [            'cell_phone'=>$cell,
            'car'=>$car,
            'cell_model'=>$cell_model,
            'cell_price'=>$cell_price,
            'car_model'=>$car_model,
            'car_price'=>$car_price];
        DB::table('products')->where('id','=',$id)->update($data);
        return redirect()->route('product.listing');

    }

    public function search(Request $req){
        $searchTerm = $req->search;
        $product = DB::table('products')->select()
        ->where('cell_phone', 'LIKE', "%{$searchTerm}%") 
        ->orWhere('car', 'LIKE', "%{$searchTerm}%")
        ->orWhere('car_model', 'LIKE', "%{$searchTerm}%")
        ->orWhere('car_price', 'LIKE', "%{$searchTerm}%")
        ->get();
        $html = "<table>";
        $html .= "<tr>";
        $html .= "<td>Car";
        $html .= "</td></tr>";
        foreach($product as $value){
            $html .= "<tr><td>";
            $html .= $value->car;
            $html .= "</tr></td></table";
        }
        echo $html;
    }
}
