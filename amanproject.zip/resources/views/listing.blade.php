@extends('layouts.master')

@section('title', 'Page Title')

@section('sidebar')
<br>
<input type="text" name="search" class="search form-control col-lg-6"><br>
<input type="submit" name="submit" class="btn btn-secondary submit" ><hr>
    <table class="table table-bordered table-active table-hover">
    	<tr class="table-dark">
    		<td>
    			No#
    		</td>
    		<td>
    			Cell phones
    		</td>

            <td>
                Cell Model
            </td>
            <td>
                Cell Price
            </td>         
    		<td>
    			Car
    		</td>
            <td>
                Car Model
            </td>
            <td>
                Car Price
            </td>
    		<td>
    			Actions
    		</td>
    	</tr>
        @php
        $i = 1;
        @endphp
    	@foreach($product as $value)
    	<tr>
    		<td>
    			{{ $i++ }}
    		</td>
    		<td>
    			{{ $value->cell_phone }}
    		</td>
            <td>
                {{ $value->cell_model }}
            </td>
            <td>
                {{ $value->cell_price }}
            </td>
    		<td>
    			{{ $value->car }}
    		</td>
            <td>
                {{ $value->car_price }}
            </td>
            <td>
                {{ $value->car_model }}
            </td>
    		<td>
    			<a href="{{ route('product.delete',$value->id) }}" class="btn btn-outline-danger">Delete</a>
                <a href="{{ route('product.edit',$value->id) }}" class="btn btn-outline-primary">Update</a>
    		</td>
    	</tr>
    	@endforeach
        
        <div class="getdata"></div>
    </table>
<tr>
            <td>
        {{ $product->links() }}
            </td>
        </tr>
    <script>
        $(document).ready(function() {
            $('.submit').click(function(){
                var search = $('.search').val();
           $.ajax({
                url : "{{ route('product.search') }}",
                type : "POST",
                data:{        "_token": "{{ csrf_token() }}", search: search},
                success:function(data){
                    if(data == ''){                        
                        $('.table').hide();
                    }else{
                            $('.getdata').html(data);    
                    }
                    
                }
           });
            });
           
        });
    </script>

@stop