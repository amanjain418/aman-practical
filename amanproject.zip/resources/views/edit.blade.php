@extends('layouts.master')

@section('title', 'Page Title')

@section('sidebar')
<form method="post" action="{{ route('product.update') }}">
    @csrf
    <input type="hidden" name="id" value="{{ $product->id }}">
    <table class="table">
        @if(!empty($product->cell_phone) || !empty($product->cell_model) || !empty($product->cell_price))
            <tr class="cell">
                <td>
                    Cell Phone
                </td>
                <td>
                    <input type="text" name="cell" class="form-control" value="{{ $product->cell_phone }}">
                </td>
            </tr>
            <tr class="cell">
                <td>
                    Cell Model
                </td>
                <td>
                    <input type="text" name="cell_model" class="form-control" value="{{ $product->cell_model }}">
                </td>
            </tr>
            <tr class="cell">
                <td>
                    Cell Price
                </td>
                <td>
                    <input type="text" name="cell_price" class="form-control" value="{{ $product->cell_price }}">
                </td>
            </tr>
            @else
            <tr class="car">
                <td>
                    Car
                </td>
                <td>
                    <input type="text" name="car" class="form-control" value="{{ $product->car }}">
                </td>
            </tr>
            <tr class="car">
                <td>
                    Car Model
                </td>
                <td>
                    <input type="text" name="car_model" class="form-control" value="{{ $product->car_model }}">
                </td>
            </tr>
            <tr class="car">
                <td>
                    Car Price
                </td>
                <td>
                    <input type="text" name="car_price" class="form-control" value="{{ $product->car_price }}">
                </td>
            </tr>
        @endif
        <tr>
            <td>
                <input type="submit" name="submit" class="btn btn-success submit">
            </td>
        </tr>

    </table>
    </form>
    
@stop