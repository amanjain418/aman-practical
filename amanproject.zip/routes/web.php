<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('product/listing','App\Http\Controllers\ProductController@index')->name('product.listing');
Route::get('product/create','App\Http\Controllers\ProductController@create')->name('product.create');
Route::post('product/add','App\Http\Controllers\ProductController@addproduct')->name('product.add');
Route::get('product/delete/{id}','App\Http\Controllers\ProductController@delete')->name('product.delete');
Route::get('product/edit/{id}','App\Http\Controllers\ProductController@edit')->name('product.edit');

Route::post('product/update','App\Http\Controllers\ProductController@update')->name('product.update');

Route::post('product/search','App\Http\Controllers\ProductController@search')->name('product.search');
