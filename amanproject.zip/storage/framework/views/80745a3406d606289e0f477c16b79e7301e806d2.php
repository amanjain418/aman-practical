

<?php $__env->startSection('title', 'Page Title'); ?>

<?php $__env->startSection('sidebar'); ?>
<form method="post" action="<?php echo e(route('product.update')); ?>">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
    <table class="table">
        <?php if(!empty($product->cell_phone) || !empty($product->cell_model) || !empty($product->cell_price)): ?>
            <tr class="cell">
                <td>
                    Cell Phone
                </td>
                <td>
                    <input type="text" name="cell" class="form-control" value="<?php echo e($product->cell_phone); ?>">
                </td>
            </tr>
            <tr class="cell">
                <td>
                    Cell Model
                </td>
                <td>
                    <input type="text" name="cell_model" class="form-control" value="<?php echo e($product->cell_model); ?>">
                </td>
            </tr>
            <tr class="cell">
                <td>
                    Cell Price
                </td>
                <td>
                    <input type="text" name="cell_price" class="form-control" value="<?php echo e($product->cell_price); ?>">
                </td>
            </tr>
            <?php else: ?>
        <tr class="car">
            <td>
                Car
            </td>
            <td>
                <input type="text" name="car" class="form-control" value="<?php echo e($product->car); ?>">
            </td>
        </tr>
        <tr class="car">
            <td>
                Car Model
            </td>
            <td>
                <input type="text" name="car_model" class="form-control" value="<?php echo e($product->car_model); ?>">
            </td>
        </tr>
        <tr class="car">
            <td>
                Car Price
            </td>
            <td>
                <input type="text" name="car_price" class="form-control" value="<?php echo e($product->car_price); ?>">
            </td>
        </tr>
        <?php endif; ?>
        <tr>
            <td>
                <input type="submit" name="submit" class="btn btn-success submit">
            </td>
        </tr>

    </table>
    </form>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\amanproject\resources\views/edit.blade.php ENDPATH**/ ?>