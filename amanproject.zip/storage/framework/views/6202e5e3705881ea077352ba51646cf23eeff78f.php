

<?php $__env->startSection('title', 'Page Title'); ?>

<?php $__env->startSection('sidebar'); ?>
<form method="post" action="<?php echo e(route('product.add')); ?>">
    <?php echo csrf_field(); ?>

    <table class="table">
        <tr>
            <td>
     			Cell phone
            </td>
            <td>
                <select>
                	<?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                		<?php if(!empty($value->cell_phone)): ?>
                			<option value="<?php echo e($value->id); ?>">
                				<?php echo e($value->cell_phone); ?>

                			</option>
                		<?php endif; ?>
                	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </td>
        </tr>
        <tr>
            <td>
                Car
            </td>
            <td>
             <select>
                	<?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                		<?php if(!empty($value->car)): ?>
                			<option  value="<?php echo e($value->id); ?>">
                				<?php echo e($value->car); ?>

                			</option>
                		<?php endif; ?>
                	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </td>
        </tr>
        <tr>
            <td>
                <input type="submit" name="submit" class="btn btn-success">
            </td>
        </tr>
    </table>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\amanproject\resources\views/inventory/listing.blade.php ENDPATH**/ ?>