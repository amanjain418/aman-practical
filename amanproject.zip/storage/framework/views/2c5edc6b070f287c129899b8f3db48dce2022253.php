

<?php $__env->startSection('title', 'Page Title'); ?>

<?php $__env->startSection('sidebar'); ?>
<br>
<input type="text" name="search" class="search form-control col-lg-6"><br>
<input type="submit" name="submit" class="btn btn-secondary submit" ><hr>
    <table class="table table-bordered table-active table-hover">
    	<tr class="table-dark">
    		<td>
    			No#
    		</td>
    		<td>
    			Cell phones
    		</td>

            <td>
                Cell Model
            </td>
            <td>
                Cell Price
            </td>         
    		<td>
    			Car
    		</td>
            <td>
                Car Model
            </td>
            <td>
                Car Price
            </td>
    		<td>
    			Actions
    		</td>
    	</tr>
        <?php
        $i = 1;
        ?>
    	<?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    	<tr>
    		<td>
    			<?php echo e($i++); ?>

    		</td>
    		<td>
    			<?php echo e($value->cell_phone); ?>

    		</td>
            <td>
                <?php echo e($value->cell_model); ?>

            </td>
            <td>
                <?php echo e($value->cell_price); ?>

            </td>
    		<td>
    			<?php echo e($value->car); ?>

    		</td>
            <td>
                <?php echo e($value->car_price); ?>

            </td>
            <td>
                <?php echo e($value->car_model); ?>

            </td>
    		<td>
    			<a href="<?php echo e(route('product.delete',$value->id)); ?>" class="btn btn-outline-danger">Delete</a>
                <a href="<?php echo e(route('product.edit',$value->id)); ?>" class="btn btn-outline-primary">Update</a>
    		</td>
    	</tr>
    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        <div class="getdata"></div>
    </table>
<tr>
            <td>
        <?php echo e($product->links()); ?>

            </td>
        </tr>
    <script>
        $(document).ready(function() {
            $('.submit').click(function(){
                var search = $('.search').val();
           $.ajax({
                url : "<?php echo e(route('product.search')); ?>",
                type : "POST",
                data:{        "_token": "<?php echo e(csrf_token()); ?>", search: search},
                success:function(data){
                    if(data == ''){                        
                        $('.table').hide();
                    }else{
                            $('.getdata').html(data);    
                    }
                    
                }
           });
            });
           
        });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\amanproject\resources\views/listing.blade.php ENDPATH**/ ?>