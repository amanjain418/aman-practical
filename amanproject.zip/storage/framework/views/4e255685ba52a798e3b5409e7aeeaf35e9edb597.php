

<?php $__env->startSection('title', 'Page Title'); ?>

<?php $__env->startSection('sidebar'); ?>
<form method="post" action="<?php echo e(route('product.add')); ?>"><br>
    <?php echo csrf_field(); ?>
    <select class="form-control type">
        <option value="">-- Select Car Or Cell Phone --</option>
        <option value="1">Cell Phone</option>
        <option  value="2">Car</option>
    </select>
    <table class="table">
            <tr class="cell" style="display: none !important;">
                <td>
                    Cell Phone
                </td>
                <td>
                    <input type="text" name="cell" class="form-control">
                </td>
            </tr>
            <tr class="cell" style="display: none !important;">
                <td>
                    Cell Model
                </td>
                <td>
                    <input type="text" name="cell_model" class="form-control">
                </td>
            </tr>
            <tr class="cell" style="display: none !important;">
                <td>
                    Cell Price
                </td>
                <td>
                    <input type="text" name="cell_price" class="form-control">
                </td>
            </tr>
        <tr class="car" style="display: none !important;">
            <td>
                Car
            </td>
            <td>
                <input type="text" name="car" class="form-control">
            </td>
        </tr>
        <tr class="car" style="display: none !important;">
            <td>
                Car Model
            </td>
            <td>
                <input type="text" name="car_model" class="form-control">
            </td>
        </tr>
        <tr class="car" style="display: none !important;">
            <td>
                Car Price
            </td>
            <td>
                <input type="text" name="car_price" class="form-control">
            </td>
        </tr>
        <tr>
            <td>
                <input type="submit" name="submit" class="btn btn-success submit" style="display:none;">
            </td>
        </tr>
    </table>
    </form>
    <script>
        $(document).ready(function(){
                $('.type').on('change',function(){
                    if(this.value == 1){
                        $('.cell').show();
                    }else{
                        $('.cell').hide();
                    }
                    if(this.value == 2){
                        $('.car').show();
                    }else{
                        $('.car').hide();
                    }
                    if(this.value != ''){
                        $('.submit').show();
                    }else{
                        $('.submit').hide();
                    }
                });
        }); 
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\amanproject\resources\views/add.blade.php ENDPATH**/ ?>